
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('onboardingForm');
    if(form) {
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const nama = document.getElementById('nama').value || 'Mifta';
            const domisili = document.getElementById('domisili').value || 'Tanah Laut';
            localStorage.setItem('nama', nama);
            localStorage.setItem('domisili', domisili);
            window.location.href = 'home.html';
        });
    }
    const sapaan = document.getElementById('sapaan');
    if(sapaan) {
        const nama = localStorage.getItem('nama') || 'Mifta';
        const domisili = localStorage.getItem('domisili') || 'Tanah Laut';
        sapaan.textContent = `Halo, ${nama} dari ${domisili} 👋, selamat datang di GENTA!`;
    }
});
